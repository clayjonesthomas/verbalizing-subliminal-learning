"""Durable user text overlays and the only supported report-writing entry point."""
import fcntl
import html
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import tempfile

TAGS={'h1','h2','h3','h4','h5','h6','p','summary','figcaption'}
class TextEditConflict(ValueError): pass

class TextNodes(HTMLParser):
    def __init__(self, source):
        super().__init__(convert_charrefs=False)
        self.source=source;self.offsets=[0];self.stack=[];self.nodes=[]
        for line in source.splitlines(keepends=True):self.offsets.append(self.offsets[-1]+len(line))
        self.feed(source)

    def source_position(self):
        row,col=self.getpos();return self.offsets[row-1]+col

    def handle_starttag(self, tag, attrs):
        if tag=='br':return
        for node in self.stack:node['child']=True
        if tag in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:return
        attrs=dict(attrs)
        if attrs.get('id'):
            chart=next((n for n in reversed(self.stack) if 'research-chart' in n['attrs'].get('class','').split()),None)
            if chart is not None and not chart['attrs'].get('id'):chart['attrs']['id']=attrs['id']+'-card'
        start=self.source_position();self.stack.append(dict(tag=tag,start=start,content=start+len(self.get_starttag_text()),child=False,attrs=dict(attrs)))

    def handle_endtag(self, tag):
        match=next((i for i in range(len(self.stack)-1,-1,-1) if self.stack[i]['tag']==tag),None)
        if match is None:return
        node=self.stack[match];del self.stack[match:]
        if (tag in TAGS or (tag=='span' and node['attrs'].get('role')=='heading')) and not node['child'] and not any(n['tag'] in {'svg','script','style','template'} for n in self.stack):
            node['anchor']=next((n['attrs']['id'] for n in [node]+list(reversed(self.stack)) if n['attrs'].get('id')), '$document');node['end']=self.source_position();node['text']=html.unescape(re.sub(r'<br\s*/?>', '\n', self.source[node['content']:node['end']], flags=re.I));self.nodes.append(node)


def nodes(source):
    found=sorted(TextNodes(source).nodes,key=lambda n:n['start']);counts={}
    for node in found:
        stem=json.dumps([node['anchor'],node['tag'],node['attrs'].get('class','')],separators=(',',':'))
        ordinal=counts.get(stem,0);counts[stem]=ordinal+1
        node['key']=stem+':'+str(ordinal)
    return found



def resolve(edits, found):
    """Locate current fields; tolerate inserted sections, never guess ambiguity."""
    resolved=[];used=set()
    for key,edit in edits.items():
        target=next((n for n in found if n['key']==key),None) if not key.isdigit() else None
        if target is None and key.isdigit():
            index=int(key)
            if index<len(found) and found[index]['text'] in (edit['original'],edit['text']):target=found[index]
            else:
                matches=[n for n in found if n['text'] in (edit['original'],edit['text']) and n['key'] not in used]
                if len(matches)==1:target=matches[0]
        if target is not None and target['anchor']=='$document' and target['text'] not in (edit['original'],edit['text']):target=None
        if target is None or target['key'] in used:
            raise TextEditConflict('Saved text edit cannot be uniquely located; reconcile it before replacing the report: '+key)
        used.add(target['key']);resolved.append((target,edit))
    return resolved


def reapply(path, source):
    path=Path(path);sidecar=path.parent/'report_text_edits.json'
    edits=json.loads(sidecar.read_text()).get(path.name,{}) if sidecar.exists() else {}
    replacements=[(n['content'],n['end'],html.escape(e['text'],quote=False).replace('\n','<br>')) for n,e in resolve(edits,nodes(source))]
    for start,end,text in sorted(replacements,reverse=True):source=source[:start]+text+source[end:]
    return source


def write_report(path, source):
    """Atomically regenerate HTML while preserving user edits or fail closed."""
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with (path.parent/'.experiment.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        # Scientific rerenders must not drop the infrastructure charts supplied
        # by the managed watcher (cost/GPU/gradient/LR). Refresh still belongs
        # to that watcher and its scoped ledger, not to the report author.
        if path.name=='in_progress.html' and path.exists():
            previous=path.read_text();blocks=[]
            for name in ('cost','gpu','grad','lr','generations'):
                start=f'<!-- expweb:{name}:start -->';end=f'<!-- expweb:{name}:end -->'
                match=re.search(re.escape(start)+'.*?'+re.escape(end),previous,re.S)
                if match and start not in source:blocks.append(match.group())
            body=re.search(r'<body\b[^>]*>',source,re.I)
            title=re.search(r'<h1\b[^>]*>.*?</h1>',source,re.I|re.S)
            pos=title.end() if title else body.end() if body else 0
            source=source[:pos]+''.join(blocks)+source[pos:]
        output=reapply(path,source)
        fd,tmp=tempfile.mkstemp(dir=path.parent,prefix='.report-')
        try:
            with os.fdopen(fd,'w') as file:file.write(output);file.flush();os.fsync(file.fileno())
            os.replace(tmp,path)
        finally:
            if os.path.exists(tmp):os.unlink(tmp)
    return output
