"""Section permalinks for standalone and embedded research reports."""
from pathlib import Path
import html


def section_links():
    """Embed heading anchors and collapsed-section navigation once per document."""
    style='<style>.research-toggle-section{margin:20px 0}.research-toggle-section>summary{cursor:pointer;font-size:1.25rem;font-weight:600;position:relative}.research-toggle-section>summary:focus-visible{outline:2px solid #28745b;outline-offset:4px}.research-section-body{padding-top:8px}.research-section-description{font-size:13px;color:#777;margin:0 0 12px;line-height:1.45}.research-section-link{display:inline-block;vertical-align:middle;width:.8em;height:.8em;margin-right:.35em;color:inherit!important;opacity:.45;text-decoration:none;line-height:1;cursor:pointer}.research-section-link:hover,.research-section-link:focus-visible{opacity:1}.research-section-link svg{width:100%;height:100%;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}</style>'
    return style+'<script>'+Path(__file__).with_suffix('.js').read_text()+'</script>'


def toggle_section(title, content, *, section_id, description=None, expanded=True):
    """The sole report section-title builder; content is trusted rendered HTML."""
    if not str(title).strip() or not str(section_id).strip():
        raise ValueError("title and stable section_id are required")
    note = '' if description is None else '<p class="research-section-description">'+html.escape(str(description))+'</p>'
    return ('<details class="research-toggle-section" id="'+html.escape(str(section_id), quote=True)+'"'+(' open' if expanded else '')+'>'
            '<summary><span role="heading" aria-level="2">'+html.escape(str(title))+'</span></summary>'
            '<div class="research-section-body">'+note+content+'</div></details>')
