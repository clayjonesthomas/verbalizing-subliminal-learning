"""Shared inline, offline Plotly figures for research reports."""
from .core import (PLOTLY_VERSION, PLOTLY_URL, PLOTLY_SHA256, plotly_script,
                   chart_html, chart_grid, line_trace, reference_line)
from .training import nll_charts, learning_rate_chart

__all__ = ['PLOTLY_VERSION', 'PLOTLY_URL', 'PLOTLY_SHA256', 'plotly_script',
           'chart_html', 'chart_grid', 'line_trace', 'reference_line', 'nll_charts', 'learning_rate_chart']

from .timefmt import local_time, local_zone

__all__ += ['local_time', 'local_zone']
