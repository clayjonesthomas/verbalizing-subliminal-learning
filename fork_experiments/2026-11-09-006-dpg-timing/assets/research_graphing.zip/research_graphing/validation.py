"""Opt-in checks for new experiment reports; historical reports are untouched."""
import ast
from pathlib import Path
from html.parser import HTMLParser

class Charts(HTMLParser):
    def __init__(self):
        super().__init__(); self.errors=[]; self.shared=0; self.raw=0
    def handle_starttag(self, tag, attrs):
        attrs=dict(attrs); classes=attrs.get('class','').split()
        if 'research-chart' in classes: self.shared+=1
        if 'plotly-graph-div' in classes:
            self.raw+=1
            self.errors.append('Direct Plotly HTML export; use research_graphing.chart_html/chart_grid')

def check_report(folder):
    """Reject direct Plotly exports in report code and generated reports.

    This is a guardrail, not proof of every visual property. Shared chart_html
    supplies bounded heights, interaction settings and responsive containers.
    Only callers opting in should invoke this on existing experiments.
    """
    folder=Path(folder); errors=[]
    for path in folder.rglob('*.py'):
        if any(part in ('results','assets','.venv') for part in path.relative_to(folder).parts): continue
        source=path.read_text(); tree=ast.parse(source,filename=str(path))
        plotly='plotly' in source.lower()
        for node in ast.walk(tree):
            if plotly and isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr in ('to_html','write_html'):
                errors.append(f'{path.name}:{node.lineno}: use research_graphing.chart_html/chart_grid instead of direct Plotly export')
    for name in ('in_progress.html','final_report.html'):
        path=folder/name
        if path.exists():
            parser=Charts();parser.feed(path.read_text())
            errors.extend(f'{name}: {error}' for error in sorted(set(parser.errors)))
    return errors
