"""Local wall-clock labels; machine timestamps remain unchanged in source data."""
from datetime import datetime
import os
from pathlib import Path
from zoneinfo import ZoneInfo


def local_zone(name=None):
    name = name or os.environ.get('PODRUN_TIMEZONE') or os.environ.get('TZ')
    if name:
        return ZoneInfo(name)
    try:
        with Path('/etc/localtime').open('rb') as source:
            return ZoneInfo.from_file(source)
    except OSError:
        return datetime.now().astimezone().tzinfo


def local_time(value, name=None):
    if isinstance(value, (float,int)):
        dt = datetime.fromtimestamp(value, local_zone(name))
    else:
        dt = datetime.fromisoformat(str(value).replace('Z','+00:00'))
        if dt.tzinfo is None:
            return str(value)
        dt = dt.astimezone(local_zone(name))
    # strftime repeatedly consults the system timezone on macOS, even for an
    # already-localized datetime. Formatting every graph point can block HTTP
    # threads for seconds; these numeric fields need no locale conversion.
    return (f'{dt.year:04d}-{dt.month:02d}-{dt.day:02d} '
            f'{dt.hour:02d}:{dt.minute:02d}:{dt.second:02d} {dt.tzname() or ""}')
