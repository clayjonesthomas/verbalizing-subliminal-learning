"""Training-report adapters. Inputs are records, not experiment-specific paths."""
from .timefmt import local_time
from .core import chart_html, line_trace, reference_line

COLORS = ('#2563eb', '#008566', '#9333ea', '#dc2626', '#0891b2')


def hover_fields(records, started):
    return {'Step': [r['step'] for r in records],
            'Elapsed hours': [str((r['time'] - started) / 3600) for r in records],
            'Local time': [local_time(r['time']) for r in records]}


def nll_charts(histories, started, *, references=(), id_prefix='nll', labels=None, axes=('step', 'time')):
    """Return selected step/time graphs inline; references are (name, metrics, color).

    histories maps series IDs to evaluation records containing step, time,
    train.nll and valid.nll. Reference metrics use the same train/valid shape.
    Missing reference values are omitted, never treated as zero. Optional labels
    maps series IDs to display names; otherwise IDs themselves are used.
    """
    if not axes or any(axis not in ('step', 'time') for axis in axes):
        raise ValueError("axes must contain step and/or time")
    parts = []
    for axis, title, xlabel in [('step', 'NLL by optimizer step', 'Optimizer step'),
                                ('time', 'NLL by elapsed time', 'Hours since training start')]:
        if axis not in axes:
            continue
        traces = []
        for index, (key, records) in enumerate(histories.items()):
            if not records:
                continue
            x = [r['step'] if axis == 'step' else (r['time'] - started) / 3600 for r in records]
            for split, label in [('train', 'Train'), ('valid', 'Validation')]:
                traces.append(line_trace(f'{(labels or {}).get(key, key)} · {label}', x,
                    [r[split]['nll'] for r in records], value_label='NLL',
                    color=COLORS[index % len(COLORS)], dash='dash' if split == 'train' else 'solid',
                    hover_fields=hover_fields(records, started)))
        xmax = max((max(t['x']) for t in traces if t['x']), default=1)
        for name, metrics, color in references:
            for split, label in [('train', 'Train'), ('valid', 'Validation')]:
                value = metrics.get(split, {}).get('nll')
                if value is not None:
                    traces.append(reference_line(f'{name} · {label}', value, [0, xmax],
                                  color=color, dash='dot' if split == 'train' else 'dashdot'))
        parts.append(chart_html(f'{id_prefix}-{axis}', title, traces, x_label=xlabel,
                                y_label='Token-weighted NLL (nats)', height=570))
    return ''.join(parts)


def learning_rate_chart(histories, started, *, chart_id='learning-rate', labels=None):
    """Plot actual per-update rates, including warmup and plateau reductions."""
    traces = []
    for index, (key, records) in enumerate(histories.items()):
        if not records:
            continue
        traces.append(line_trace((labels or {}).get(key, key), [r['step'] for r in records],
            [r['lr'] for r in records], value_label='Learning rate',
            color=COLORS[index % len(COLORS)], shape='hv', marker_size=4,
            hover_fields=hover_fields(records, started)))
    return chart_html(chart_id, 'Learning rate', traces, x_label='Optimizer step',
                      y_label='Learning rate', height=440, zero_y=True)
