"""Section permalinks for standalone and embedded research reports."""
from pathlib import Path


def section_links():
    """Embed heading anchors and collapsed-section navigation once per document."""
    style='<style>.research-section-link{position:absolute;display:inline-block;width:.8em;height:.8em;margin-left:.35em;color:inherit!important;opacity:.45;text-decoration:none;line-height:1;cursor:pointer}.research-section-link:hover,.research-section-link:focus-visible{opacity:1}.research-section-link svg{width:100%;height:100%;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}</style>'
    return style+'<script>'+Path(__file__).with_suffix('.js').read_text()+'</script>'
