"""Dependency-free Python builders for standard Plotly.js figures."""
import copy
import colorsys
import hashlib
import html
import json
import re
from pathlib import Path
from .timefmt import local_time, local_zone
from .sections import section_links
from datetime import datetime

PLOTLY_VERSION = '3.1.0'
PLOTLY_URL = f'https://cdn.plot.ly/plotly-{PLOTLY_VERSION}.min.js'
PLOTLY_SHA256 = '122e3be346d66616944d0b83eaaf7242581508c3c1cfa0995a17af0d83eff770'
PLOT_CONFIG = dict(responsive=True, displaylogo=False, scrollZoom=False,
                   doubleClick=False, displayModeBar=False)


# Shared row tracks align plot boxes even when only one card has a summary or
# a wrapped legend. The .charts selector also upgrades existing report layouts.
CHART_GRID_STYLE = """<style>
.research-chart-grid,.charts:has(>.research-chart){display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr));grid-auto-flow:row;gap:0 16px;align-items:stretch;min-width:0;max-width:100%;column-count:auto}
.research-chart-grid>.research-chart,.charts:has(>.research-chart)>.research-chart{width:100%!important;max-width:100%!important;min-width:0;margin:12px 0!important;align-self:stretch}
@supports(grid-template-rows:subgrid){
.research-chart-grid>.research-chart,.charts:has(>.research-chart)>.research-chart{display:grid;grid-row:span 5;grid-template-rows:subgrid}
:is(.research-chart-grid,.charts:has(>.research-chart))>.research-chart>:is(h2,h3,.research-chart-title){grid-row:1}
:is(.research-chart-grid,.charts:has(>.research-chart))>.research-chart>.research-chart-summary{grid-row:2}
:is(.research-chart-grid,.charts:has(>.research-chart))>.research-chart>div:not(.research-chart-legend):not(.research-chart-title){grid-row:3}
:is(.research-chart-grid,.charts:has(>.research-chart))>.research-chart>.research-chart-legend{grid-row:4;align-self:start}
:is(.research-chart-grid,.charts:has(>.research-chart))>.research-chart>.research-chart-caption{grid-row:5;align-self:start}
}
@media(max-width:480px){.research-chart-grid,.charts:has(>.research-chart){grid-template-columns:minmax(0,1fr)}}
</style>"""


def chart_grid(charts, *, columns=2):
    """Arrange chart_html cards in aligned two-column rows (one on phones).

    Default columns=2. Set columns=1 only when the user explicitly requests
    a full-width/single-column layout; one graph does not imply full width.
    Each row reserves shared space for headings, summaries, plots, legends and
    captions; the next row follows the tallest card, never a masonry column.
    """
    if columns not in (1, 2):
        raise ValueError('columns must be 1 or 2')
    style = ' style="grid-template-columns:minmax(0,1fr)"' if columns == 1 else ''
    return CHART_GRID_STYLE + '<div class="research-chart-grid"' + style + '>' + ''.join(charts) + '</div>'


def script_json(value):
    """JSON safe inside a script element, without changing numeric precision."""
    return json.dumps(value, ensure_ascii=False, allow_nan=False).replace('<', '\\u003c').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029')


def plotly_script(bundle_path):
    """Embed a verified local bundle once per report; never fetch at render time."""
    bundle = Path(bundle_path).read_bytes()
    if hashlib.sha256(bundle).hexdigest() != PLOTLY_SHA256:
        raise ValueError('Plotly bundle checksum mismatch')
    return '<script>' + bundle.decode('utf-8') + '</script>' + section_links()


def series_color(name):
    """Stable default for a legend label, independent of trace order or process."""
    digest = hashlib.sha256(str(name).encode('utf-8')).digest()
    hue = int.from_bytes(digest[:4], 'big') / 2**32
    red, green, blue = colorsys.hls_to_rgb(hue, .43, .65)
    return '#{:02x}{:02x}{:02x}'.format(*(round(v * 255) for v in (red, green, blue)))


def line_trace(name, x, y, *, value_label='Value', color=None, dash='solid',
               shape='linear', hover_fields=None, marker_size=6, timezone_name=None):
    """Keep exact stored values as strings in hover; show every series initially.

    hover_fields maps display labels to arrays aligned with x/y. No downsampling.
    """
    x, y = list(x), list(y)
    fields = {}
    for key, values in (hover_fields or {}).items():
        values = list(values)
        if key.lower() in ('utc','time','timestamp','local time','step / time'):
            values = [local_time(value,timezone_name) if isinstance(value,(float,int)) and value>1e9 else
                      local_time(value,timezone_name) if isinstance(value,str) and ('T' in value and ('+' in value or value.endswith('Z'))) else value for value in values]
            if key.lower() == 'utc':
                key = 'Local time'
        fields[key] = values
    temporal = bool(x) and all(isinstance(value,(int,float)) and 1e9<value<1e11 for value in x)
    if temporal:
        fields.setdefault('Local time',[local_time(value,timezone_name) for value in x])
        x = [value*1000 for value in x]
    if len(x) != len(y) or any(len(values) != len(x) for values in fields.values()):
        raise ValueError('x, y and hover fields must have equal lengths')
    custom = [[str(value), *[html.escape(str(values[i])) for values in fields.values()]]
              for i, value in enumerate(y)]
    hover = html.escape(str(name)) + '<br>' + html.escape(value_label) + ': %{customdata[0]}'
    for i, label in enumerate(fields, 1):
        hover += '<br>' + html.escape(str(label)) + ': %{customdata[' + str(i) + ']}'
    return dict(type='scatter', mode='lines', name=str(name), x=x, y=y,
                customdata=custom, visible=True, connectgaps=False,
                meta=dict(time_axis=temporal, timezone=timezone_name),
                line=dict(color=color or series_color(name), dash=dash, shape=shape), marker=dict(size=marker_size),
                hovertemplate=hover + '<extra></extra>')


def reference_line(name, value, x_range, *, value_label='NLL', color='#64748b', dash='dot'):
    trace = line_trace(name, x_range, [value, value], value_label=value_label, color=color, dash=dash)
    trace['mode'] = 'lines'
    return trace


def chart_html(chart_id, title, traces, *, x_label, y_label, height=380, zero_y=False, hovermode="closest", caption=None, summary=None, section_id=None, show_legend=None, group_points=False, secondary_y_label=None):
    """One always-visible graph. Include plotly_script() before the first chart.

    Title and optional summary are owned by this card; do not wrap it in another titled card.
    Single-series legends are redundant and hidden unless explicitly requested.
    Multi-series legends occupy normal document flow below the entire plot,
    so wrapped labels cannot collide with x-axis ticks or titles.
    group_points offsets scatter series within shared categorical x positions.
    Optional caption text stays inside the same responsive column as the graph.
    Each chart needs a unique chart_id. Hover is enabled; zoom/pan, mode-bar and
    view-switch controls are disabled. Caller data is never mutated.
    Named series have stable label-based default colors across charts and renders.
    Explicit caller colors and per-point color arrays are preserved.
    """
    if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]*', chart_id):
        raise ValueError('chart_id must be an HTML identifier')
    if section_id is not None and not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]*', section_id):
        raise ValueError('section_id must be an HTML identifier')
    traces = copy.deepcopy(list(traces))
    palette = ['#636efa', '#ef553b', '#00cc96', '#ab63fa', '#ffa15a', '#19d3f3']
    # The HTML legend and Plotly must share explicit colors. Plotly's bare-JS
    # defaults differ from the palette historically used by our HTML swatches.
    for index, trace in enumerate(traces):
        kind = trace.get('type', 'scatter')
        default_color = series_color(trace['name']) if trace.get('name') is not None else palette[index % len(palette)]
        if kind in ('scatter', 'scattergl'):
            line = trace.setdefault('line', {})
            marker = trace.setdefault('marker', {})
            marker_color = marker.get('color')
            color = line.get('color') or (marker_color if isinstance(marker_color, str) else None) or default_color
            if not line.get('color'):
                line['color'] = color
            if marker_color is None:
                marker['color'] = color
        elif kind in ('bar', 'histogram', 'box', 'violin'):
            marker = trace.setdefault('marker', {})
            if marker.get('color') is None:
                marker['color'] = default_color
    if show_legend is None:
        show_legend = sum(trace.get('showlegend', True) is not False for trace in traces) > 1
    layout = dict(paper_bgcolor='white', plot_bgcolor='white', colorway=palette,
                  font=dict(family='Arial, sans-serif'), height=height,
                  margin=dict(l=0, r=20, t=10, b=80, autoexpand=True), dragmode=False,
                  showlegend=False,
                  hovermode=hovermode, hoverdistance=25,
                  xaxis=dict(fixedrange=True, title=dict(text=x_label, standoff=8), automargin=True, showspikes=True),
                  yaxis=dict(fixedrange=True, title=dict(text=y_label, standoff=8), automargin=True, showspikes=True))
    if secondary_y_label:
        layout['yaxis2'] = dict(overlaying='y', side='right', fixedrange=True, automargin=True, showgrid=False, title=dict(text=secondary_y_label, standoff=8))
    temporal = [trace for trace in traces if isinstance(trace.get('meta'),dict) and trace['meta'].get('time_axis')]
    if temporal:
        name = temporal[0]['meta'].get('timezone')
        values = [x for trace in temporal for x in trace['x']]
        first,last = min(values),max(values)
        ticks = [first+(last-first)*index/5 for index in range(6)] if last>first else [first]
        layout['xaxis'].update(type='date', tickmode='array', tickvals=ticks,
            ticktext=[datetime.fromtimestamp(value/1000,local_zone(name)).strftime('%H:%M') for value in ticks],
            title=dict(text='Local time' + (' · '+name if name else ''), standoff=8))
    if group_points:
        layout.update(scattermode='group', scattergap=0.25)
    if zero_y:
        layout['yaxis']['rangemode'] = 'tozero'
    figure = script_json(dict(data=list(traces), layout=layout))
    config = script_json(PLOT_CONFIG)
    legend_html = ''
    legend_script = ''
    if show_legend:
        buttons = []
        for index, trace in enumerate(traces):
            if trace.get('showlegend') is False:
                continue
            marker_color = (trace.get('marker') or {}).get('color')
            line_color = (trace.get('line') or {}).get('color')
            is_line = trace.get('type', 'scatter') in ('scatter', 'scattergl') and 'lines' in trace.get('mode', 'lines+markers')
            color = str((line_color if is_line else None) or (marker_color if isinstance(marker_color, str) else None) or line_color or palette[index % len(palette)])
            if not re.fullmatch(r'#[0-9a-fA-F]{3,8}|[a-zA-Z]+|rgba?\([\d.,%\s]+\)', color):
                color = '#64748b'
            dash = 'solid' if (trace.get('line') or {}).get('dash', 'solid') == 'solid' else 'dashed'
            pressed = 'false' if trace.get('visible') in (False, 'legendonly') else 'true'
            swatch = f'<span class="research-legend-swatch" style="border-top-color:{color};border-top-style:{dash}" aria-hidden="true"></span>'
            if not is_line and (trace.get('marker') or {}).get('symbol') == 'diamond':
                swatch = f'<svg class="research-legend-diamond" width="18" height="12" viewBox="0 0 18 12" style="flex:0 0 18px" aria-hidden="true"><path d="M9 0L15 6L9 12L3 6Z" fill="{color}"/></svg>'
            buttons.append(f'<button type="button" data-trace="{index}" aria-controls="{chart_id}" aria-pressed="{pressed}">'
                           + swatch +
                           '<span>' + html.escape(str(trace.get('name', f'Series {index + 1}'))) + '</span></button>')
        legend_html = f'<div id="{chart_id}-legend" class="research-chart-legend" role="group" aria-label="Chart series">' + ''.join(buttons) + '</div>'
        legend_script = ('document.getElementById(' + script_json(chart_id + '-legend') + ').querySelectorAll("button").forEach(button=>{'
                         'button.addEventListener("click",()=>{const visible=button.getAttribute("aria-pressed")!=="true";'
                         'Plotly.restyle(' + script_json(chart_id) + ',{visible:visible?true:"legendonly"},[Number(button.dataset.trace)]);'
                         'button.setAttribute("aria-pressed",String(visible));});});')
    section_attr = '' if section_id is None else f' id="{section_id}"'
    heading_html = '' if not title else '<div class="research-chart-title">' + html.escape(str(title)) + '</div>'
    summary_html = '' if summary is None else '<p class="research-chart-summary">' + html.escape(str(summary)) + '</p>'
    caption_html = '' if caption is None else '<p class="research-chart-caption">'+html.escape(str(caption))+'</p>'
    return (CHART_GRID_STYLE + '<style>.research-chart{display:inline-block;vertical-align:top;box-sizing:border-box;width:calc(50% - 12px);margin:12px 6px!important;min-width:0}.research-chart .research-chart{width:100%;margin:0!important}.research-chart>.research-chart-title{font-size:1.17em;font-weight:bold;box-sizing:border-box;width:100%;max-width:100%;margin:0 0 6px;text-align:center;white-space:normal;overflow-wrap:anywhere}.research-chart>.research-chart-caption{box-sizing:border-box;width:100%;max-width:100%;margin:4px 0 0;color:#626c7c;font-size:13px;line-height:1.45;white-space:normal;overflow-wrap:anywhere}.research-chart-legend{display:flex;flex-wrap:wrap;gap:4px 12px;width:100%;max-width:100%;margin:8px 0 12px;padding:0}.research-chart-legend button{display:flex;align-items:baseline;gap:6px;min-width:0;max-width:100%;border:0;background:transparent;padding:4px 0;font:12px/1.4 Arial,sans-serif;color:inherit;text-align:left;white-space:normal;overflow-wrap:anywhere;cursor:pointer}.research-chart-legend button span:last-child{min-width:0}.research-chart-legend button[aria-pressed="false"]{opacity:.45}.research-chart-legend button:focus-visible{outline:2px solid #28745b;outline-offset:2px}.research-legend-swatch{display:inline-block;flex:0 0 18px;border-top-width:3px;transform:translateY(-3px)}@media(max-width:480px){.research-chart{width:100%;margin:12px 0!important}}</style>'
            f'<section{section_attr} class="research-chart">' + heading_html + summary_html + f'<div id="{chart_id}" style="height:{int(height)}px;width:100%"></div>' + legend_html + caption_html +
            '<script>{const figure=' + figure + ';Plotly.newPlot(' + script_json(chart_id) +
            ',figure.data,figure.layout,' + config + ');' + legend_script + '}</script></section>')
